# Copyright (c) 1994 Adam Karpierz
# SPDX-License-Identifier: Zlib

__import__("pkg_about").about("crc-ct")
