# Copyright (c) 2012 Adam Karpierz
# SPDX-License-Identifier: Zlib

__import__("pkg_about").about()
