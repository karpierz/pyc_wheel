# Copyright (c) 2016 Adam Karpierz
# SPDX-License-Identifier: Zlib

from .__about__ import * ; del __about__  # noqa

from ._slownie import * ; del _slownie  # noqa
